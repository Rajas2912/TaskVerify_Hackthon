package com.example.demo.repository;

import com.example.demo.controller.Assignment;

import java.util.List;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin(origins = "http://localhost:5173")
@Repository
public interface AssignmentRepository extends JpaRepository<Assignment, Integer> {
    // You can add custom query methods here if needed
}
