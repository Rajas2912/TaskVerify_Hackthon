package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.List;
import java.util.Map;

import com.example.demo.controller.Submission;

@CrossOrigin(origins = "http://localhost:5173")
@Repository
public interface SubmissionRepository extends JpaRepository<Submission, Integer> {
	
	@Query("SELECT DISTINCT s.assignid FROM Submission s")
    List<Integer> findDistinctAssignIds();
	 
	
	@Query("SELECT CONCAT(FLOOR(CAST(s.score AS integer) / 10) * 10, '-', FLOOR(CAST(s.score AS integer) / 10) * 10 + 9) AS scoreRange, COUNT(s.sid) AS numberOfStudents " +
		       "FROM Submission s " +
		       "WHERE s.assignid = :assignmentId " +
		       "GROUP BY FLOOR(CAST(s.score AS integer) / 10) " +
		       "ORDER BY FLOOR(CAST(s.score AS integer) / 10)")
		List<Map<String, Object>> findScoreDistributionByAssignmentId(@Param("assignmentId") int assignmentId);

}
