package com.example.demo.controller;

import org.springframework.web.bind.annotation.*;
import com.example.demo.repository.AssignmentRepository;
import com.example.demo.repository.LeaderboardRepository;
import com.example.demo.repository.StudentRepository;
import com.example.demo.repository.SubmissionRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.transaction.Transactional;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/api/submissions") // Base path for submissions
public class StudentDbHandler {

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private SubmissionRepository submissionRepository; // Repository for Submission entity
    @Autowired
    private AssignmentRepository assignmentRepository;
    
    @Autowired
    private LeaderboardRepository leaderboardRepository;
    
    @Autowired
    private StudentRepository studentRepository;
    @PostMapping("/save")
    @Transactional
    public ResponseEntity<String> saveSubmission(
            @RequestParam("sid") int sid,
            @RequestParam("assignid") int assignid,
            @RequestParam("score") String score) {

        try {
            // Save the submission using the renamed method saveSubmissionEntity
            saveSubmissionEntity(sid, assignid, score);
            return ResponseEntity.ok("Submission saved successfully");
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Failed to save submission: " + e.getMessage());
        }
    }
    
    @PostMapping("/create")
    public ResponseEntity<String> createAssignment(@RequestBody Assignment assignment) {
        try {
            // Save the assignment using the repository
            assignmentRepository.save(assignment);
            return ResponseEntity.ok("Assignment created successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error creating assignment: " + e.getMessage());
        }
    }
    
    @Transactional
    public void saveSubmissionEntity(int sid, int assignid, String score) {
        Submission submission = new Submission(sid, assignid, score);
        entityManager.persist(submission);
    }
    
    @Transactional
    public void saveAssignment(int aid, String aname, String aans) {
        // Create a new Assignment object with the given parameters
        Assignment assignment = new Assignment(aid, aname, aans);

        // Persist the assignment object to the database
        entityManager.persist(assignment);
    }
    
    // New Login Method for Teachers
    @PostMapping("/teacherLogin")
    public ResponseEntity<String> teacherLogin(@RequestParam("username") String uname, @RequestParam("password") String pass) {
        if (isTeacherLoginValid(uname, pass)) {
            return ResponseEntity.ok("Teacher login successful!");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid teacher credentials!");
        }
    }

    // New Login Method for Students
    @PostMapping("/studentLogin")
    public ResponseEntity<String> studentLogin(@RequestParam("username") String uname, @RequestParam("password") String pass) {
        if (isStudentLoginValid(uname, pass)) {
            return ResponseEntity.ok("Student login successful!");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid student credentials!");
        }
    }

    // Helper Method for Teacher Login Validation
    public boolean isTeacherLoginValid(String uname, String pass) {
        System.out.println(uname + " " + pass);
        String query = "SELECT t FROM Teacher t WHERE t.tuname = :uname AND t.tpass = :pass";
        try {
            TypedQuery<Teacher> typedQuery = entityManager.createQuery(query, Teacher.class);
            typedQuery.setParameter("uname", uname);
            typedQuery.setParameter("pass", pass);

            // Using getResultList() for safer handling of results
            return !typedQuery.getResultList().isEmpty(); // Returns true if a matching teacher is found
        } catch (Exception e) {
            e.printStackTrace(); // Print the stack trace for debugging
            return false; // Login failed if an exception is thrown
        }
    }

    // Helper Method for Student Login Validation
    public boolean isStudentLoginValid(String uname, String pass) {
        String query = "SELECT s FROM Student s WHERE s.suname = :uname AND s.spass = :pass";
        try {
            TypedQuery<Student> typedQuery = entityManager.createQuery(query, Student.class);
            typedQuery.setParameter("uname", uname);
            typedQuery.setParameter("pass", pass);
            return !typedQuery.getResultList().isEmpty(); // Returns true if a matching student is found
        } catch (Exception e) {
            e.printStackTrace(); // Print the stack trace for debugging
            return false; // Login failed if an exception is thrown
        }
    }
    
    // New Method to Get Ideal Answer by Assignment ID
    @GetMapping("/idealAnswer/{assignmentId}")
    public ResponseEntity<String> getIdealAnswerByAssignmentId(@PathVariable Long assignmentId) {
        try {
            // Use the entity field names in the query, not the column names
            String query = "SELECT a.aans FROM Assignment a WHERE a.aid = :assignmentId";
            TypedQuery<String> typedQuery = entityManager.createQuery(query, String.class);
            typedQuery.setParameter("assignmentId", assignmentId);
            String idealAnswer = typedQuery.getSingleResult();
            return ResponseEntity.ok(idealAnswer);
        } catch (NoResultException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Ideal answer not found for assignment ID: " + assignmentId);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An error occurred while retrieving the ideal answer: " + e.getMessage());
        }
    }
    
    @GetMapping("/leaderboard/{assignmentId}")
    public List<Submission> getSubmissionsByAssignmentId( @PathVariable int assignmentId) {
        List<Submission> lists = leaderboardRepository.findSubmissionsByAssignmentId(assignmentId);
        System.out.println( "Hi"+ lists);
    	return lists;
    }
    @GetMapping("/usernames")
    public List<Student> getUsernamesBySids(@RequestParam List<Integer> sids) {
        return studentRepository.findBySidIn(sids);
    }
    @GetMapping("/assignments/ids")
    public List<Integer> getDistinctAssignIds() {
        return submissionRepository.findDistinctAssignIds();
    }
    
    
    
    @GetMapping("/score-distribution/{assignmentId}")
    public ResponseEntity<?> getScoreDistribution(@PathVariable int assignmentId) {
        try {
            List<Map<String, Object>> scoreDistribution = submissionRepository.findScoreDistributionByAssignmentId(assignmentId);
            return ResponseEntity.ok(scoreDistribution);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to fetch score distribution.");
        }
    }


}
