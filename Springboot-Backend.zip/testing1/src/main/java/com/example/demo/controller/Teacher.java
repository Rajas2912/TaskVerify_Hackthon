package com.example.demo.controller;

import org.springframework.web.bind.annotation.CrossOrigin;

import jakarta.persistence.*;


@CrossOrigin(origins = "http://localhost:5173")
@Entity
@Table(name = "teacher")
public class Teacher {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int tid;

    @Column(name = "tuname", length = 30)
    private String tuname;

    @Column(name = "tpass", length = 30)
    private String tpass;

	public Teacher(int tid, String tuname, String tpass) {
		super();
		this.tid = tid;
		this.tuname = tuname;
		this.tpass = tpass;
	}
	
	public Teacher() {
		
	}

    // Constructors, getters, setters, toString() methods
}
