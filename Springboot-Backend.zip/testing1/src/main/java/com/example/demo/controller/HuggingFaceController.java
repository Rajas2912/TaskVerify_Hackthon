package com.example.demo.controller;

import com.example.demo.dto.ImageUrlRequest;
import com.example.demo.service.HuggingFaceService;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/api/huggingface") // Allow CORS for this specific controller
public class HuggingFaceController {

    private final HuggingFaceService huggingFaceService;

    public HuggingFaceController(HuggingFaceService huggingFaceService) {
        this.huggingFaceService = huggingFaceService;
    }

    @PostMapping("/predict")
    public String predict(@RequestBody ImageUrlRequest imageUrlRequest) {
        return huggingFaceService.callModelAPI(imageUrlRequest.getImageUrl());
    }

}
