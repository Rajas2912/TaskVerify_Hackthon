package com.example.demo.controller;

import org.springframework.web.bind.annotation.CrossOrigin;

import jakarta.persistence.*;

@CrossOrigin(origins = "http://localhost:5173")
@Entity
@Table(name = "assignment")
public class Assignment {

    @Id
    @Column(name = "aid")
    private int aid;  // Primary key, not auto-generated

    @Column(name = "aname", length = 1000)
    private String aname;

    @Column(name = "aans", length = 10000)
    private String aans;

    // Default constructor (required by JPA)
    public Assignment() {
    }

    // Constructor with all fields
    public Assignment(int aid, String aname, String aans) {
        this.aid = aid;
        this.aname = aname;
        this.aans = aans;
    }

    // Getters and Setters
    public int getAid() {
        return aid;
    }

    public void setAid(int aid) {
        this.aid = aid;
    }

    public String getAname() {
        return aname;
    }

    public void setAname(String aname) {
        this.aname = aname;
    }

    public String getAans() {
        return aans;
    }

    public void setAans(String aans) {
        this.aans = aans;
    }

    @Override
    public String toString() {
        return "Assignment{" +
                "aid=" + aid +
                ", aname='" + aname + '\'' +
                ", aans='" + aans + '\'' +
                '}';
    }
}