package com.example.demo.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.ResponseEntity;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;


@Service
public class HuggingFaceService {

    private final String MODEL_API_URL = "https://tonic-got-ocr.hf.space/call/ocr_demo"; // Initial API URL
    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;
    
    public HuggingFaceService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
        this.objectMapper = new ObjectMapper();
    }

    public String callModelAPI(String imageUrl) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");

        // Create the request body for the initial call
        String requestBody = String.format(
            "{\"data\":[{\"path\":\"%s\"},\"Plain Text OCR\",\"ocr\",\"100,200,300,400\",\"red\"]}",
            imageUrl
        );

        HttpEntity<String> requestEntity = new HttpEntity<>(requestBody, headers);
        ResponseEntity<String> response = restTemplate.postForEntity(MODEL_API_URL, requestEntity, String.class);

        if (response.getStatusCode().is2xxSuccessful()) {
            try {
                JsonNode jsonResponse = objectMapper.readTree(response.getBody());
                String eventId = jsonResponse.get("event_id").asText();
                return fetchResult(eventId); // Call the method to fetch the result
            } catch (Exception e) {
                throw new RuntimeException("Error processing the response: " + e.getMessage());
            }
        } else {
            throw new RuntimeException("Error calling Hugging Face model API: " + response.getStatusCode());
        }
    }

    private String fetchResult(String eventId) {
        String resultApiUrl = MODEL_API_URL + "/" + eventId; // Create the result URL
        ResponseEntity<String> response = restTemplate.getForEntity(resultApiUrl, String.class);

        if (response.getStatusCode().is2xxSuccessful()) {
            return response.getBody(); // Process the response as needed
        } else {
            throw new RuntimeException("Error fetching result from Hugging Face API: " + response.getStatusCode());
        }
    }
}
