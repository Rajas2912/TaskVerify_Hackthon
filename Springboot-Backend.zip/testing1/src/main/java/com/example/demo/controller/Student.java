package com.example.demo.controller;

import jakarta.persistence.*;

@Entity
@Table(name = "student")
public class Student {
    
    public Student() {
        // Default constructor
    }
    
    public Student(int sid, String suname, String spass) {
        this.sid = sid;
        this.suname = suname;
        this.spass = spass;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int sid;

    @Column(name = "suname", length = 30, nullable = false) // Added nullable = false for validation
    private String suname;

    @Column(name = "spass", length = 30, nullable = false) // Added nullable = false for validation
    private String spass;

    // Getters
    public int getSid() {
        return sid;
    }

    public String getSuname() {
        return suname;
    }

    public String getSpass() {
        return spass;
    }

    // Setters
    public void setSid(int sid) {
        this.sid = sid;
    }

    public void setSuname(String suname) {
        this.suname = suname;
    }

    public void setSpass(String spass) {
        this.spass = spass;
    }

    // toString method for easier debugging
    @Override
    public String toString() {
        return "Student{" +
                "sid=" + sid +
                ", suname='" + suname + '\'' +
                ", spass='" + spass + '\'' +
                '}';
    }
}
