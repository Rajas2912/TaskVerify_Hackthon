package com.example.demo;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cloudinary.Cloudinary;

@SpringBootApplication
public class Testing1Application {

	public static void main(String[] args) {
		SpringApplication.run(Testing1Application.class, args);
	}
	

}
