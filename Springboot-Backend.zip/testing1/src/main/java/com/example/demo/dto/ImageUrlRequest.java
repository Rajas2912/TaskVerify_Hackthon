package com.example.demo.dto;

public class ImageUrlRequest {
    private String imageUrl;

    // Constructor
    public ImageUrlRequest() {}

    // Getter and Setter
    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}

