package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.json.JSONObject;
import org.json.JSONArray;
import java.util.HashMap;
import java.util.Map;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/api/comparison")
public class AnswerComparisonController {

    // Read the Hugging Face API URL and Token from the application.properties file
    @Value("${huggingface.api.url}")
    private String huggingFaceApiUrl;

    @Value("${huggingface.api.token}")
    private String huggingFaceApiToken;

    @PostMapping("/compare")
    public ResponseEntity<?> compareAnswers(@RequestBody Map<String, String> requestPayload) {
        System.out.println("method called ");
    	// Extract idealAnswer and userAnswer from requestPayload
        String idealAnswer = requestPayload.get("idealAnswer");
        String userAnswer = requestPayload.get("userAnswer");
        
//        System.out.println(idealAnswer);
//        System.out.println(userAnswer);

        if (idealAnswer == null || userAnswer == null || idealAnswer.isEmpty() || userAnswer.isEmpty()) {
        	System.out.println("method c1 ");
            return ResponseEntity.badRequest().body("Invalid request: Both 'idealAnswer' and 'userAnswer' must be provided.");
        }

        // Log the incoming request
//        System.out.println("method c2 ");
        System.out.println("Received Request: idealAnswer = " + idealAnswer + ", userAnswer = " + userAnswer);

        // Create JSON payload for the Hugging Face API
        JSONObject payload = new JSONObject();
        JSONObject inputs = new JSONObject();
        inputs.put("source_sentence", idealAnswer);

        // Convert user answer into a JSON array
        JSONArray sentences = new JSONArray();
        sentences.put(userAnswer);
        inputs.put("sentences", sentences);

        payload.put("inputs", inputs);

        // Log the payload being sent
        System.out.println("Payload Sent to API: " + payload.toString());

        // Set up headers with the Hugging Face API token
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + huggingFaceApiToken);
        headers.set("Content-Type", "application/json");

        // Create HTTP entity with headers and payload
        HttpEntity<String> entity = new HttpEntity<>(payload.toString(), headers);
        
        System.out.println("method c4");

        // Use RestTemplate to send request to Hugging Face API
        RestTemplate restTemplate = new RestTemplate();
        String response;
        try {
            response = restTemplate.postForObject(huggingFaceApiUrl, entity, String.class);
            // Log the response for debugging
            System.out.println("Response from Hugging Face API: " + response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error communicating with Hugging Face API: " + e.getMessage());
        }
        System.out.println("method ended ");
        return ResponseEntity.ok(response);
    }
}
