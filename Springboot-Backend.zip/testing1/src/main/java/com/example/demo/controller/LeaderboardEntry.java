package com.example.demo.controller;
public class LeaderboardEntry {
    private Long assignmentId;
    private Long studentId;
    private Integer score;

    public LeaderboardEntry(){
    	
    }
    public LeaderboardEntry(Long assignmentId, Long studentId, Integer score) {
        this.assignmentId = assignmentId;
        this.studentId = studentId;
        this.score = score;
    }

    // Getters and Setters
    public Long getAssignmentId() {
        return assignmentId;
    }

    public void setAssignmentId(Long assignmentId) {
        this.assignmentId = assignmentId;
    }

    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }
}
