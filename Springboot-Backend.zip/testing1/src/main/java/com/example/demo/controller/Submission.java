package com.example.demo.controller;
import org.springframework.web.bind.annotation.CrossOrigin;

import jakarta.persistence.*;


@CrossOrigin(origins = "http://localhost:5173")
@Entity
@Table(name = "submissions")
public class Submission {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @Column(name = "sid")  // Represents the foreign key for the Student ID
    private int sid;

    @Column(name = "assignid")  // Represents the foreign key for the Assignment ID
    private int assignid;

    @Column(name = "score")
    private String score;

    // Constructors
    public Submission() {
    }

    public Submission(int sid, int assignid, String  score) {
        this.sid = sid;
        this.assignid = assignid;
        this.score = score;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSid() {
        return sid;
    }

    public void setSid(int sid) {
        this.sid = sid;
    }

    public int getAssignid() {
        return assignid;
    }

    public void setAssignid(int assignid) {
        this.assignid = assignid;
    }

    public String  getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    @Override
    public String toString() {
        return "Submission{" +
                "id=" + id +
                ", sid=" + sid +
                ", assignid=" + assignid +
                ", score=" + score +
                '}';
    }
}